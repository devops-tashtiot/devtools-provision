* Update appVersions for DC apps (#823)
